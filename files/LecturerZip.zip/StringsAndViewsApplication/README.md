# StringsAndViewsApplication
An android studio project made to test if a student can reference a string resource during both compile time and run time

# Build Status
[![Build Status](https://app.bitrise.io/app/23d48c2954cc7472/status.svg?token=zEMpl0yU0zwMQdENyU90rw)](https://app.bitrise.io/app/23d48c2954cc7472)

# Code Coverage
[![Coverage Status](https://coveralls.io/repos/github/OpenSauce-Wits/StringsAndViewsApplication/badge.svg?branch=master)](https://coveralls.io/github/OpenSauce-Wits/StringsAndViewsApplication?branch=master)
